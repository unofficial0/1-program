﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_1Library
{
    public class Employee
    {
        public int EmpId { get; set; }
        public String EmpName { get; set; }
        public  String Adress { get; set; }
        public string Department { get; set; }
        public string City { get; set; }
        public double Salary { get; set; }
    }
}
