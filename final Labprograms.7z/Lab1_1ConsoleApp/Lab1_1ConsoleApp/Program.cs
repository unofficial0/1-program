﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab1_1Library;

namespace Lab1_1ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee[] emp = new Employee[2];
            for (int i = 0; i < emp.Length; i++)
            {
                emp[i] = new Employee();
                Console.WriteLine("Enter employee id:");
                emp[i].EmpId = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter employee Name:");
                emp[i].EmpName =Console.ReadLine();
                Console.WriteLine("Enter employee Adress:");
                emp[i].Adress = Console.ReadLine();
                Console.WriteLine("Enter employee city:");
                emp[i].City = Console.ReadLine();
                Console.WriteLine("Enter employee department:");
                emp[i].Department = Console.ReadLine();
                Console.WriteLine("Enter employee Salary:");
                emp[i].Salary = Convert.ToDouble(Console.ReadLine());
            }
            foreach (var item in emp)
            {
                Console.WriteLine("EmployeeName:"+item.EmpName+", EmployeeSalary:"+item.Salary);
                Console.ReadKey();
            }
        }
    }
}
